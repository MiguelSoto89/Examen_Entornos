public class cadena {
	
	private String cad1;
	private String cad2;
	private int num1;
	private int num2;
	
	public String union_cadenas(String cad1, String cad2) {
		return cad1+cad2;
	}
	
	public String cadena_mayuscula(String cad1) {
		return cad1.toUpperCase();
	}
	
	public int numero_elementos(String cad1) {
		return cad1.length();
	}
	
	public int mayor(int num1, int num2) {
		if(num1>=num2)
			return 1;
		else
			return 0;	
	}
	
	public int cuadrado(int num1) {
		return num1*num1;
	}
	
	public int MayorDiez(int num1) {
		if(num1>10)
			return true;
		else
			return false;
	}
	
}