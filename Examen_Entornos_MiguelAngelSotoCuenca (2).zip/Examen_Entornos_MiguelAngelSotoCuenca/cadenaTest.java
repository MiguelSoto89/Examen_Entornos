import static org.junit.jupiter.api.Assertions.*;

import org.junit.After;
import org.junit.Before;
import org.junit.jupiter.api.Test;

import Examen_Entornos.cadena;

class cadenaTest {

	private cadena micadena;
	private cadena minumero;
	private int resultado;
	
	@Before
	public void creacadena() {
		micadena = new cadena("Hola", "Mundo");
		minumero = new cadena(5, 6);
	}
	
	@After
	public void borracadena() {
		micadena = null;
		minumero = null;
	}

	@Test
	public void testUnion_Cadenas() {
		resultado = micadena.union_cadenas();
		assertEquals(resultado, "HolaMundo");
	}
	
	@Test
	public void testCadena_mayuscula() {
		resultado = micadena.cadena_mayuscula();
		assertEquals(resultado, "HOLA");
	}
	
	@Test
	public void testNumero_Elementos() {
		resultado = micadena.numero_elementos();
		assertEquals(resultado, 4);
	}
	
	@Test
	public void testMayor() {
		resultado = minumero.mayor();
		assertEquals(resultado, 0);
	}
	
	@Test
	public void testCuadrado() {
		resultado = minumero.cuadrado();
		assertEquals(resultado, 25);
	}
	
	@test
	public void testMayorDiez() {
		resultado = minumero.MayorDiez();
		assertEquals(resultado, false);
	}

}